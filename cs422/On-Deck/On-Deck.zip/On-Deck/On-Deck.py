# This is the main file to run the program

import interface

def main():
    screen = interface.Interface()
    screen.start()
    return

if __name__ == "__main__":
    main()
