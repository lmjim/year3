activeRoster = []
passiveRoster = []